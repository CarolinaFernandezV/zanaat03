
===============================
ZANAAT INTEGRADO - INSTRUCCIONES
===============================

Este proyecto contiene dos partes:
1. /site  -> Sitio principal (cliente/usuarios)
2. /admin -> Panel de administración y login

-------------------------------
PARA VER LA PÁGINA FUNCIONAL
-------------------------------

✅ OPCIÓN 1: SIN PHP (solo HTML/JS)
-----------------------------------
Puedes hacer doble clic en estos archivos para abrirlos en tu navegador:

- /site/index.html        -> Página principal para clientes
- /admin/loginadm.html    -> Login del administrador
- /admin/admin.html       -> Panel administrativo (sin login)

✅ OPCIÓN 2: CON PHP Y BASE DE DATOS
-------------------------------------
1. Instala un servidor local como XAMPP, WAMP o MAMP.
2. Copia toda la carpeta "zanaat_integrado" a:

   En XAMPP: C:\xampp\htdocs\zanaat_integrado

3. Inicia Apache y MySQL desde el panel de control de XAMPP.
4. Importa la base de datos:
   - Abre http://localhost/phpmyadmin
   - Crea una base de datos (por ejemplo, zanaat)
   - Importa el archivo: /site/mibd.sql

5. Abre en tu navegador:
   - http://localhost/zanaat_integrado/site/index.html
   - http://localhost/zanaat_integrado/admin/loginadm.html

¡Listo! Ya puedes navegar y probar la página completa.

-------------------------------
ARCHIVOS DESTACADOS
-------------------------------
- /site/index.html          -> Página principal
- /admin/loginadm.html      -> Login para administrador
- /site/conexion.php        -> Conexión a la base de datos
- /site/mibd.sql            -> Estructura o datos de la base

