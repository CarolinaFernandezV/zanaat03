let productosGlobal = [];

document.addEventListener("DOMContentLoaded", () => {
  const contenedor = document.getElementById("productos-container");
  if (!contenedor) return;

  fetch("productos.json")
    .then(res => res.json())
    .then(productos => {
      productosGlobal = productos.map((p, index) => ({ ...p, id: index }));

      contenedor.innerHTML = "";

      productosGlobal.forEach((producto, index) => {
        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
          <div class="img-container">
            <img src="${producto.imagen}" alt="${producto.nombre}" style="width: 150px;">
            <div class="hover-info">Especificaciones</div>
          </div>
          <h3 class="nombre">${producto.nombre}</h3>
          <p class="precio">$${producto.precio.toFixed(2)}</p>
          <button class="btn-agregar" data-index="${index}">Agregar al carrito</button>
        `;
        contenedor.appendChild(div);
      });

      document.querySelectorAll(".btn-agregar").forEach(boton => {
        boton.addEventListener("click", function () {
          const index = this.dataset.index;
          agregarAlCarrito(productosGlobal[index]);
        });
      });
    });
});


function actualizarContadorCarrito() {
  const carrito = JSON.parse(localStorage.getItem("carrito")) || [];
  const total = carrito.reduce((acc, p) => acc + p.cantidad, 0);
  const contador = document.getElementById("contador-carrito");
  const contadorItems = document.getElementById("itemCount");

  if (contador) contador.textContent = total;
  if (contadorItems) contadorItems.textContent = total;
}
