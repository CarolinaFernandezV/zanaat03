<?php
require 'conexion.php';

$datos = json_decode(file_get_contents("php://input"), true);

$nombre = $conn->real_escape_string($datos['nombre']);
$contacto = $conn->real_escape_string($datos['contacto']);
$telefono = $conn->real_escape_string($datos['telefono']);
$correo = $conn->real_escape_string($datos['correo']);

$sql = "INSERT INTO proveedores (nombre, contacto, telefono, correo)
        VALUES ('$nombre', '$contacto', '$telefono', '$correo')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Proveedor registrado correctamente."]);
} else {
    echo json_encode(["success" => false, "message" => "Error: " . $conn->error]);
}
?>
