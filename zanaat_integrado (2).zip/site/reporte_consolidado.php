<?php
require 'conexion.php';

header('Content-Type: application/json');

$sql = "SELECT pp.id, pp.fecha, pp.estado, pr.nombre AS proveedor, p.nombre AS producto, dpp.cantidad
        FROM pedidos_proveedor pp
        JOIN proveedores pr ON pr.id = pp.proveedor_id
        JOIN detalle_pedidos_proveedor dpp ON dpp.pedido_id = pp.id
        JOIN productos p ON p.id = dpp.producto_id";

$result = $conn->query($sql);
$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        'id' => $row['id'],
        'fecha' => $row['fecha'],
        'estado' => $row['estado'],
        'proveedor' => $row['proveedor'],
        'producto' => $row['producto'],
        'cantidad' => $row['cantidad']
    ];
}

echo json_encode($data);
?>
