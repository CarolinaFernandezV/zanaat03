let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

document.addEventListener("DOMContentLoaded", () => {
  renderizarCarrito();
  document.getElementById("btn-agregar-carrito").addEventListener("click", agregarProductoActual);
  document.getElementById("openCartBtn").addEventListener("click", () => {
  document.getElementById("cartSidebar").classList.add("active");
});

document.getElementById("closeCartBtn").addEventListener("click", () => {
  document.getElementById("cartSidebar").classList.remove("active");
});

   document.querySelector(".checkout-btn").addEventListener("click", () => {
  if (carrito.length === 0) {
    alert("Tu carrito está vacío.");
    return;
  }
  window.location.href = "carrito.html";
});

});

function agregarAlCarrito(producto) {
  const existente = carrito.find(p => p.nombre === producto.nombre);
  if (existente) {
    existente.cantidad += 1;
  } else {
    carrito.push({ nombre: producto.nombre, precio: producto.precio, cantidad: 1 });
  }

  guardarCarrito();
  renderizarCarrito();

  Swal.fire({
  icon: 'success',
  title: 'Agregado al carrito',
  text: producto.nombre,
  showConfirmButton: false,
  timer: 1200
});

}


function renderizarCarrito() {
  const contenedor = document.getElementById("cartItems");
  contenedor.innerHTML = "";

  let total = 0;
  let itemCount = 0;

  carrito.forEach((item, index) => {
    total += item.precio * item.cantidad;
    itemCount += item.cantidad;

    const div = document.createElement("div");
    div.className = "cart-item";
    div.innerHTML = `
      <p><strong>${item.nombre}</strong></p>
      <p>Precio: $${item.precio}</p>
      <p>
        Cantidad: 
        <button onclick="cambiarCantidad(${index}, -1)">➖</button> 
        ${item.cantidad} 
        <button onclick="cambiarCantidad(${index}, 1)">➕</button>
      </p>
      <button onclick="eliminarProducto(${index})">❌ Eliminar</button>
      <hr>
    `;
    contenedor.appendChild(div);
  });

  document.getElementById("cartTotal").textContent = total.toFixed(2);
  document.getElementById("contador-carrito").textContent = itemCount;
  document.getElementById("itemCount").textContent = itemCount;
}

function cambiarCantidad(index, delta) {
  carrito[index].cantidad += delta;
  if (carrito[index].cantidad <= 0) {
    carrito.splice(index, 1);
  }
  guardarCarrito();
  renderizarCarrito();
}

function eliminarProducto(index) {
  carrito.splice(index, 1);
  guardarCarrito();
  renderizarCarrito();
}

function guardarCarrito() {
  localStorage.setItem("carrito", JSON.stringify(carrito));
}
