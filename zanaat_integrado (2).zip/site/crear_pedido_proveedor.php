<?php
require 'conexion.php';

$datos = json_decode(file_get_contents("php://input"), true);

$proveedor_id = intval($datos['proveedor_id']);
$producto = $conn->real_escape_string($datos['producto']);
$cantidad = intval($datos['cantidad']);
$observaciones = $conn->real_escape_string($datos['observaciones']);
$fecha = date('Y-m-d H:i:s');

// Insertar pedido en tabla pedidos_proveedores
$sql1 = "INSERT INTO pedidos_proveedor (proveedor_id, fecha, estado, observaciones)
         VALUES ($proveedor_id, '$fecha', 'Pendiente', '$observaciones')";

if ($conn->query($sql1)) {
    $pedido_id = $conn->insert_id;

    // Insertar en detalle_pedidos_proveedor
    $sql2 = "SELECT id FROM productos WHERE nombre = '$producto' LIMIT 1";
    $res2 = $conn->query($sql2);
    
    if ($res2->num_rows > 0) {
        $producto_id = $res2->fetch_assoc()['id'];
    } else {
        // Si no existe el producto, insertarlo primero
        $conn->query("INSERT INTO productos (nombre, precio, stock, proveedor_id) VALUES ('$producto', 0, 0, $proveedor_id)");
        $producto_id = $conn->insert_id;
    }

    $sql3 = "INSERT INTO detalle_pedidos_proveedor (pedido_id, producto_id, cantidad)
             VALUES ($pedido_id, $producto_id, $cantidad)";
    
    if ($conn->query($sql3)) {
        echo json_encode(["success" => true, "message" => "Pedido generado correctamente."]);
    } else {
        echo json_encode(["success" => false, "message" => "Error al registrar el detalle del pedido."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Error al registrar el pedido."]);
}
?>
