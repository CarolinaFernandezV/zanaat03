<?php
require 'conexion.php';

$sql = "SELECT p.id, p.fecha, p.estado, dp.cantidad, pr.nombre AS producto
        FROM pedidos p
        JOIN detalle_pedidos dp ON dp.pedido_id = p.id
        JOIN productos pr ON pr.id = dp.producto_id";

$res = $conn->query($sql);
$datos = [];

while ($row = $res->fetch_assoc()) {
    $datos[] = [
        'id' => $row['id'],
        'fecha' => $row['fecha'],
        'estatus' => $row['estado'],
        'producto' => $row['producto'],
        'cantidad' => $row['cantidad']
    ];
}

echo json_encode($datos);
?>
