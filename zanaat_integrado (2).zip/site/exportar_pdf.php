<?php
require 'conexion.php';
require 'fpdf/fpdf.php';

$pdf = new FPDF();
$pdf->AddPage('L');
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Reporte Consolidado de Pedidos a Proveedores', 0, 1, 'C');

$pdf->Ln(5);
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(230, 230, 230);
$pdf->Cell(30, 8, 'Fecha', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Pedido ID', 1, 0, 'C', true);
$pdf->Cell(50, 8, 'Proveedor', 1, 0, 'C', true);
$pdf->Cell(80, 8, 'Producto', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Cantidad', 1, 0, 'C', true);
$pdf->Cell(40, 8, 'Estatus', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 10);

$sql = "SELECT pp.id, pp.fecha, pp.estado, pr.nombre AS proveedor, p.nombre AS producto, dpp.cantidad
        FROM pedidos_proveedor pp
        JOIN proveedores pr ON pr.id = pp.proveedor_id
        JOIN detalle_pedidos_proveedor dpp ON dpp.pedido_id = pp.id
        JOIN productos p ON p.id = dpp.producto_id";

$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $pdf->Cell(30, 8, date('d/m/Y', strtotime($row['fecha'])), 1);
    $pdf->Cell(30, 8, $row['id'], 1);
    $pdf->Cell(50, 8, utf8_decode($row['proveedor']), 1);
    $pdf->Cell(80, 8, utf8_decode($row['producto']), 1);
    $pdf->Cell(30, 8, $row['cantidad'], 1);
    $pdf->Cell(40, 8, $row['estado'], 1);
    $pdf->Ln();
}

$pdf->Output('I', 'reporte_consolidado.pdf');
?>
