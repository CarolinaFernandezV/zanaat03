<?php
require 'conexion.php';

header('Content-Type: application/json');

$response = [];

// Total de pedidos de clientes
$clientes = $conn->query("SELECT COUNT(*) AS total FROM pedidos");
$response['totalPedidosClientes'] = $clientes->fetch_assoc()['total'];

// Total de pedidos a proveedores
$proveedores = $conn->query("SELECT COUNT(*) AS total FROM pedidos_proveedor");
$response['totalPedidosProveedores'] = $proveedores->fetch_assoc()['total'];

// Total de pedidos entregados (clientes + proveedores)
$entregados = $conn->query("
  SELECT 
    (SELECT COUNT(*) FROM pedidos WHERE estado = 'Entregado') +
    (SELECT COUNT(*) FROM pedidos_proveedor WHERE estado = 'Entregado') AS total
");
$response['totalEntregados'] = $entregados->fetch_assoc()['total'];

// Ventas simuladas: suma de productos en pedidos
$ventas = $conn->query("
  SELECT SUM(dp.cantidad * dp.precio_unitario) AS total 
  FROM detalle_pedidos dp
");
$response['ventasSimuladas'] = $ventas->fetch_assoc()['total'] ?? 0;

echo json_encode($response);
?>

