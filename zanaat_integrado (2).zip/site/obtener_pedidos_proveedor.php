<?php
require 'conexion.php';

$sql = "SELECT pp.id, pp.fecha, pp.estado, pp.observaciones, pr.nombre AS proveedor, prod.nombre AS producto, dpp.cantidad
        FROM pedidos_proveedor pp
        JOIN proveedores pr ON pr.id = pp.proveedor_id
        JOIN detalle_pedidos_proveedor dpp ON dpp.pedido_id = pp.id
        JOIN productos prod ON prod.id = dpp.producto_id";

$res = $conn->query($sql);
$datos = [];

while ($row = $res->fetch_assoc()) {
    $datos[] = [
        'id' => $row['id'],
        'fecha' => $row['fecha'],
        'estado' => $row['estado'],
        'observaciones' => $row['observaciones'],
        'proveedor' => $row['proveedor'],
        'producto' => $row['producto'],
        'cantidad' => $row['cantidad']
    ];
}

echo json_encode($datos);
?>
