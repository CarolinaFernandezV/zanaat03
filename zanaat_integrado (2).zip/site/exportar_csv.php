<?php
require 'conexion.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="reporte_consolidado.csv"');

$output = fopen('php://output', 'w');

// Encabezados
fputcsv($output, ['Fecha', 'Pedido ID', 'Proveedor', 'Producto', 'Cantidad', 'Estatus']);

// Datos
$sql = "SELECT pp.id, pp.fecha, pp.estado, pr.nombre AS proveedor, p.nombre AS producto, dpp.cantidad
        FROM pedidos_proveedor pp
        JOIN proveedores pr ON pr.id = pp.proveedor_id
        JOIN detalle_pedidos_proveedor dpp ON dpp.pedido_id = pp.id
        JOIN productos p ON p.id = dpp.producto_id";

$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        date('d/m/Y', strtotime($row['fecha'])),
        $row['id'],
        $row['proveedor'],
        $row['producto'],
        $row['cantidad'],
        $row['estado']
    ]);
}

fclose($output);
exit;
?>
