    <?php
    require 'conexion.php';

    $nombre = $conn->real_escape_string($_POST['nombre']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $telefono = $conn->real_escape_string($_POST['telefono']);

    $sql = "INSERT INTO crm_descargas (nombre, correo, telefono) 
            VALUES ('$nombre', '$correo', '$telefono')";

    if ($conn->query($sql)) {
        // Ruta del archivo a descargar (ajústala a tu estructura)
        $rutaArchivo = "../pdf/manual-artesania.pdf";

        if (file_exists($rutaArchivo)) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="manual-artesania.pdf"');
            readfile($rutaArchivo);
            exit;
        } else {
            echo "El archivo no existe.";
        }
    } else {
        echo "Error al guardar los datos: " . $conn->error;
    }
    ?>
